//
//  TimerTableViewCell.h
//  TimerDemo
//
//  Created by Alex on 2017/6/4.
//  Copyright © 2017年 Alex. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TimerTableViewCell : UITableViewCell

-(void)setWorkFlowTime:(NSString *)workFlowTime workFlowTitle:(NSString *)workFlowTitle timeDifference:(NSString *)timeDifference;

@end
